export { default as PokemonApiResult } from './pokemon-api-result';
export { default as Pokemon } from './pokemon';
export { default as PokemonSpecie } from './pokemon-specie';
export { default as EvolutionChain } from './evolutuon-chain';
export { default as Type } from './type';
