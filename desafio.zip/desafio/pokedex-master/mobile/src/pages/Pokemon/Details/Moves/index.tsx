import React from 'react';
import { Text } from 'react-native';

// import { Container } from './styles';

const Moves = () => {
  return <Text>Moves</Text>;
};

export default Moves;
