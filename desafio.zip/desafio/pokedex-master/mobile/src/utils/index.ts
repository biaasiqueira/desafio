export { default as convertValues } from './convertValues';
export { default as getColorByPokemonType } from './getColorByPokemonType';
export { default as replaceString } from './replaceString';
export { default as getPokemonGenderStats } from './getPokemonGenderStats';
